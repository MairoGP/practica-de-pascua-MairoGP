# Practica de Pascua

Se proporciona una base sobre la que trabajar. Es un programa con dos clases que implementan la interfaz utilizable. Debéis elegir una clase cuyos objetos:
* Tengan al menos un atributo String
* Tengan al menos un atributo double

Se implementarán todos los métodos de la interfaz Utilizable de modo que el programa ListaGUI **sin modificar** funcione correctamente.

Los ficheros serán ficheros de datos (**no ficheros de texto**). En los ejemplos se usan ficheros de texto.

La fecha límite es el viernes de vuelta de vacaciones.


